package com.cookandroid.androidtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText userID, userPassWd;
    Button btnLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("로그인");
        userID = (EditText) findViewById(R.id.userID);
        userPassWd = (EditText) findViewById(R.id.userPassWd);
        btnLogin = (Button)findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (userID.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "아이디를 입력하세요", Toast.LENGTH_SHORT).show();
                } else if (userPassWd.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "비밀번호를 입력하세요", Toast.LENGTH_SHORT).show();
                } else if (!userID.getText().toString().equals("admin")) {
                    Toast.makeText(getApplicationContext(), "아이디가 틀립니다.", Toast.LENGTH_SHORT).show();
                } else if (!userPassWd.getText().toString().equals("admin1234")) {
                    Toast.makeText(getApplicationContext(), "비밀번호가 틀립니다.", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(getApplicationContext(),SecondActivity.class);
                startActivity(intent);}
            }
        });
    }
}
